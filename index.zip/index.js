var AWS = require('aws-sdk');
var s3 = new AWS.S3();

exports.handler = (event, context, callback) => {
  var bucketName = "concertnotifier";
  var keyName = "users.json"

  return readFile(bucketName, keyName, readFileContent, onError);
};

function readFile(bucketName, filename, onFileContent, onError) {
  var params = {
    Bucket: bucketName,
    Key: filename
  };
  var content;
  s3.getObject(params, function(err, data) {
    if (!err)
      content = onFileContent(filename, data.Body.toString());
    else
      console.log(err);
      content = { statusCode: 500, body: "Couldn't read users file" }
  });
  return content;
}

function readFileContent(filename, content) {
  return { statusCode:200, body: content };
}

function onError(err) {
  console.log('error: ' + err);
}
